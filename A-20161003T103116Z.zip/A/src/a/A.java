
package a;
import java.util.*;


public class A {

        //private int input;
        
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in); 
        
        int test = scan.nextInt();
        
        for(int i = 0 ; i<test ; i++){
            int number = scan.nextInt();
            int square = squareOfaNum(number);
            System.out.println(square);
        }
        
        
    }
    public static int squareOfaNum( int num){
        return num*num;
    }
    
}
